package com.example.edreichua.myruns2;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * Created by edreichua on 4/22/16.
 */

public class MapDisplayActivity extends FragmentActivity implements ServiceConnection{

    // Variables dealing with the map
    private GoogleMap mMap;
    public Marker startLoc;

    // Variables dealing with database
    private ExerciseEntryDbHelper entryHelper;
    private ExerciseEntry entry;
    private String activityType;
    private String inputType;

    // Variables dealing with service connection
    private ServiceConnection mConnection = this;
    private TrackingService trackingService;
    private Intent serviceIntent;

    // Variable dealing with whether the service is bound to the activity
    boolean mIsBound;


    /////////////////////// Broadcast receiver ///////////////////////

    final static String ACTION = "NotifyLocationUpdate";
    private final BroadcastReceiver updateLocationReceiver = new LocationReceiver() {
        @Override
        protected void onLocationReceived(Context context, Location loc) {
            if (!TrackingService.isRunning())
                return;
            Log.d("Testing", "location received! location is: " + loc.toString());
            getExerciseEntryFromService();
            drawTraceOnMap();
        }
    };


    /////////////////////// Override core functionality ///////////////////////

    /**
     * Handle creating of activity
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Create main layout
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_display);

        // Set up the map
        setUpMapIfNeeded();

        // Start service
        startService();

        // For use in service connection
        serviceIntent = new Intent(this, TrackingService.class);

        mIsBound = false;

        // Bind service
//        bindService();
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable(){
            @Override
            public void run() {
                bindService();
            }
        }, 100);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
    }

    @Override
    public void onStart() {
        super.onStart();
        registerReceiver(updateLocationReceiver,
                new IntentFilter(ACTION));
    }

    protected void onPause(){
        unregisterReceiver(updateLocationReceiver);
        super.onPause();
    }


    /////////////////////// Binding with Tracking Service ///////////////////////

    public void startService(){

        Intent mIntent = new Intent(this, TrackingService.class);
        if(getParentActivityIntent() != null) {
            Bundle bundle = getIntent().getExtras();
            activityType = StartFragment.ID_TO_ACTIVITY[bundle.getInt(StartFragment.ACTIVITY_TYPE, 0)];
            inputType = StartFragment.ID_TO_INPUT[bundle.getInt(StartFragment.INPUT_TYPE, 0)];
            mIntent.putExtras(bundle);
        }
        startService(mIntent);
    }

    public void bindService(){

        if (TrackingService.isRunning()) {
            bindService(serviceIntent, mConnection,
                    Context.BIND_AUTO_CREATE);
            mIsBound = true;
            Log.d("Testing", "should have bound service");
        }
    }

    public void getExerciseEntryFromService(){
        Log.d("Testing", "about to try to get exercise entry from trackingservice");
        entry = trackingService.getExerciseEntry();
    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        Log.d("Testing", "service connected");
        trackingService =  ((TrackingService.TrackingBinder) service).getReference();
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {

    }

    @Override
    protected void onDestroy() {

        // Destroy notification and tracking service
        Log.d("Testing", "start destroy");
        Intent intent = new Intent();
        intent.setAction(TrackingService.ACTION);
        intent.putExtra(TrackingService.STOP_SERVICE_BROADCAST_KEY, TrackingService.RQS_STOP_SERVICE);
        sendBroadcast(intent);
        Log.d("Testing", "destroyed");

        // Destroy broadcast receiver
        //this.unregisterReceiver(updateLocationReceiver);

        super.onDestroy();
    }


    /////////////////////// Handle Selection of buttons ///////////////////////

    /**
     * Handle the selection of the save button
     * @param v
     */
    public void selectGPSSave(View v) {
        // Close the activity
        finish();
    }

    /**
     * Handle the selection of the cancel button
     * @param v
     */
    public void selectGPSCancel(View v) {
        // Close the activity
        finish();
    }

    public void drawTraceOnMap(){

        Log.d("Testing", "location list: " + entry.getmLocationList().toString());
        if(entry.getmLocationList().size() == 1) {
            LatLng latlng = entry.getmLocationList().get(0);
            startLoc = mMap.addMarker(new MarkerOptions().position(latlng).icon(BitmapDescriptorFactory.defaultMarker(
                    BitmapDescriptorFactory.HUE_GREEN)));
            // Zoom in
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latlng,
                    17));
        }
    }


    /////////////////////// Updating stats functionality ///////////////////////

    public void saveEntryToDb(){

    }

    /**
     * Update stats on text views
     */
    public  void updateStat(){

        // Set the text view for type
        TextView gpsType = (TextView) findViewById(R.id.gps_type);
        gpsType.setText(formatType("Running")); // hardcoded for now

        // Set the text view for average speed
        TextView gpsAvgSpeed = (TextView) findViewById(R.id.gps_avg_speed);
        gpsAvgSpeed.setText(formatAvgSpeed(0.0,"Kilometers")); // hardcoded for now

        // Set the text view for current speed
        TextView gpsCurSpeed = (TextView) findViewById(R.id.gps_cur_speed);
        gpsCurSpeed.setText(formatCurSpeed(0.0, "Kilometers")); // hardcoded for now

        // Set the text view for climb
        TextView gpsClimb = (TextView) findViewById(R.id.gps_climb);
        gpsClimb.setText(formatClimb(0.0, "Kilometers")); // hardcoded for now

        // Set the text view for calorie
        TextView gpsCalorie = (TextView) findViewById(R.id.gps_calories);
        gpsCalorie.setText(formatCalories(0)); // hardcoded for now

        // Set the text view for distance
        TextView gpsDistance = (TextView) findViewById(R.id.gps_distance);
        gpsDistance.setText(formatDistance(0.0,"Kilometers")); // hardcoded for now
    }

    /**
     * format activity type
     * @param activity
     * @return
     */
    public static String formatType(String activity){
        return "Type: "+activity;
    }

    /**
     * format average speed
     * @param speed
     * @param unitPref
     * @return
     */
    public static String formatAvgSpeed(Double speed, String unitPref){
        String unit = "km/h";
        if (unitPref.equals("Miles")) {
            speed /= ManualEntryActivity.MILES2KM; // converts from km to miles
            unit = "m/h";
        }
        return "Avg speed: "+String.format("%.2f", speed)+" "+unit;
    }

    /**
     * format current speed
     * @param speed
     * @param unitPref
     * @return
     */
    public static String formatCurSpeed(Double speed, String unitPref){
        String unit = "km/h";
        if (unitPref.equals("Miles")) {
            speed /= ManualEntryActivity.MILES2KM; // converts from km to miles
            unit = "m/h";
        }
        return "Cur speed: "+String.format("%.2f", speed)+" "+unit;
    }

    /**
     * format climb
     * @param climb
     * @param unitPref
     * @return
     */
    public static String formatClimb(Double climb, String unitPref){
        return "Climb: "+String.format("%.2f", climb)+" "+unitPref;
    }

    /**
     * format calories
     * @param cal
     * @return
     */
    public static String formatCalories(int cal){
        return "Calorie: "+cal;
    }

    /**
     * format distance
     * @param distance
     * @param unitPref
     * @return
     */
    public static String formatDistance(double distance, String unitPref) {
        if (unitPref.equals("Miles")) {
            distance /= ManualEntryActivity.MILES2KM; // converts from km to miles
        }
        return "Distance: "+String.format("%.2f", distance)+" "+unitPref;
    }


    /////////////////////// Map functionality ///////////////////////

    /**
     * Function to set up map
     */
    private void setUpMapIfNeeded() {
        if (mMap == null) {
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            if (mMap != null) {
                setUpMap();
            }
        }
    }

    /**
     * Setting up map, with a point new Africa for visual effect
     */
    private void setUpMap() {
        mMap.addMarker(new MarkerOptions().position(new LatLng(0, 0)).title("Africa"));
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
    }
}
